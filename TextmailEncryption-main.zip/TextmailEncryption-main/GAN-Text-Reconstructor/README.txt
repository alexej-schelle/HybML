GAN-Text-Reconstructor
