Non-Reversible-GAN
